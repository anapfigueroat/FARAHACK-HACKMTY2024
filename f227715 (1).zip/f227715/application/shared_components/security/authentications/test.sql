prompt --application/shared_components/security/authentications/test
begin
--   Manifest
--     AUTHENTICATION: test
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(38886856539613365573)
,p_name=>'test'
,p_scheme_type=>'NATIVE_EXTENSION'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'   -- Declare variables in the BEGIN block for APEX processes',
'   declare',
'      v_user_id users.user_id%type;',
'      v_email    varchar2(100) := :P9999_USERNAME;  -- Replace with actual page item for username',
'      v_password varchar2(100) := :P9999_PASSWORD;  -- Replace with actual page item for password',
'   begin',
'      -- Main executable block',
'      select user_id',
'        into v_user_id',
'        from users',
'       where email = v_email',
'         and password = v_password;',
'',
'      -- Set session state',
'      apex_util.set_session_state(''USER_ID'', v_user_id);',
'',
'   exception',
'      when no_data_found then',
'         -- Raise error if the user isn''t found',
'         raise_application_error(-20001, ''Invalid email or password'');',
'   end;',
'end;',
'',
''))
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>15569784293092
);
wwv_flow_imp.component_end;
end;
/
