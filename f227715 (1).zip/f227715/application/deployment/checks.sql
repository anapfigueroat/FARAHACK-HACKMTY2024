prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 227715
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
null;
wwv_flow_imp.component_end;
end;
/
