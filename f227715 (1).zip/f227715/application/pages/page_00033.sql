prompt --application/pages/page_00033
begin
--   Manifest
--     PAGE: 00033
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>33
,p_name=>'Login'
,p_alias=>'LOGIN1'
,p_step_title=>'Login'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38771728727279775437)
,p_plug_name=>'login'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38505837143081204650)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT user_id, nombre, password ',
'FROM users ',
'WHERE email = :P33_USERNAME ',
'  AND password = :P33_PASSWORD;',
''))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38829735917416828012)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(38771728727279775437)
,p_button_name=>'P33_LOGIN_BUTTON'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_image_alt=>'Login'
,p_button_condition=>'P33_LOGIN_BUTTON'
,p_button_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742016946817055234)
,p_name=>'P33_USERNAME'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(38771728727279775437)
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742017012187055235)
,p_name=>'P33_PASSWORD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(38771728727279775437)
,p_prompt=>'New'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742017718307055242)
,p_name=>'P33_USER_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38771728727279775437)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   v_user_id users.user_id%TYPE;',
'BEGIN',
'   -- Validate the user credentials and fetch user_id',
'   SELECT user_id',
'   INTO v_user_id',
'   FROM users',
'   WHERE email = :P33_USERNAME',
'   AND password = :P33_PASSWORD;',
'',
'   RETURN v_user_id;',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38742017650127055241)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(38771728727279775437)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Login'
,p_internal_uid=>38742017650127055241
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38742017591614055240)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process User Login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_user_id users.user_id%TYPE;',
'BEGIN',
'  -- Validate credentials (email and password)',
'  SELECT user_id INTO v_user_id',
'  FROM users',
'  WHERE email = :P33_USERNAME',
'  AND password = :P33_PASSWORD;',
'',
'  -- Set session state for USER_ID (hidden item)',
'  :P33_USER_ID := v_user_id;',
'',
'EXCEPTION',
'  WHEN NO_DATA_FOUND THEN',
'    raise_application_error(-20001, ''Invalid login credentials. Please try again.'');',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38829735917416828012)
,p_internal_uid=>38742017591614055240
);
wwv_flow_imp.component_end;
end;
/
