prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'INITIAL PROMPT ENGINE'
,p_alias=>'INITIALPROMPT'
,p_step_title=>'Initial Prompt'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APP_FILES#InitialPromptEngine#MIN#.js',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Custom CSS for Login Page Button */',
'',
'body {',
'        display: flex;',
'        flex-direction: column;',
'        align-items: center;',
'        justify-content: top;',
'        margin: 0;',
'        font-family: Arial, sans-serif;',
'        text-align: center; /* Center text */',
'    }',
'',
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 7px 15px;',
'    border: solid 1px #7023bf;',
'    font-size: 12px;',
'    cursor: pointer;',
'}',
'',
'.custom-login-button:hover {',
'    background-color: #7f58fd;',
'    color: #ffffff;',
'}',
'',
'.custom-singup-button {',
'    background-color: #7023bf;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button:hover {',
'    background-color: #ffffff;',
'    color: #7023bf;',
'}',
'',
'.t-Login-containerBody{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Login-region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(18deg, #7023bf 1%, #ffffff 23%, #ffffff 90%, #7f58fd 99%);',
'}',
'',
'.t-Form-fieldContainer{',
' background-color: transparent;',
'    border-radius: 10px;',
'}',
'',
'/* Styles for the login form */',
'',
'/* Remove background colors from form elements */ ',
'',
'.text_field,',
'.password {',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'    height: 40px;',
'     /* Remove background colors */',
'}',
'',
'.apex-item-icon {',
'    color: #7f58fd !important; /* Set color to purple */',
'}',
'.t-Region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Region-header{',
'    font-size: 1.8rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'     background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Button{',
'    box-shadow: none !important;',
'}',
'',
'.t-Button--icon{',
'    border: none !important;',
'    font-size: 30px;',
'    color: #7f58fd;',
'}',
'',
'.t-Button--tiny {',
'     background-color: transparent;',
'    font-size: 1em; /* Font size */',
'    margin-left: -80%; /* Moves the button to the left */',
'    margin-top: 20px; /* Adjusts the vertical position */',
'}',
'',
'.a-Button{',
'    color: white;',
'    background-color: #7023bf;',
'    border: none;',
'}',
'',
'textarea{',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    ',
'}',
'.apex-item-group--textarea{',
'border: solid 1px #7023bf;',
'}',
'',
'.t-Region-body{',
'    color: #7f58fd;',
'}',
'',
'.t-Form-labelContainer{',
'    color: #7023bf;',
'}',
'',
'.js-show-label{',
'    color: #7023bf;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38671539331711586232)
,p_plug_name=>'New'
,p_title=>'Write your Goals'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38505896682520204680)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'USERS'
,p_include_rowid_column=>false
,p_optimizer_hint=>'im gay'
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P14_INITIAL_PROMPT'
,p_plug_header=>'Welcome to Habits, I''m your AI companion, Mindful.ai. Write down your objectives and dreams so i can help you get a little more close to achieving them each day. '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38893854512660889805)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38671539331711586232)
,p_button_name=>'SAVE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505969542729204719)
,p_button_image_alt=>'SAVE'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38671539243470586231)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38671539331711586232)
,p_button_name=>'Generate'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Set'
,p_button_position=>'CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'custom-singup-button'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38671536743765586206)
,p_name=>'P14_USER_ID'
,p_item_sequence=>20
,p_source=>'1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38671536870751586207)
,p_name=>'P14_CONTEXT'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38671537529899586214)
,p_name=>'P14_SYSTEM_PROMPT'
,p_item_sequence=>60
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Provide helpful habits and mental health tips based on my profile ',
''))
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38671538551971586224)
,p_name=>'P14_HABITS'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38671539589495586234)
,p_name=>'P14_USER_ID_1'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38671539331711586232)
,p_item_source_plug_id=>wwv_flow_imp.id(38671539331711586232)
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38671540582265586244)
,p_name=>'P14_INITIAL_PROMPT'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(38671539331711586232)
,p_item_source_plug_id=>wwv_flow_imp.id(38671539331711586232)
,p_placeholder=>'Start writing...'
,p_source=>'INITIAL_PROMPT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855061705889810)
,p_name=>'P14_FREQUENCY'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855101141889811)
,p_name=>'P14_START_DATE'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855291815889812)
,p_name=>'P14_END_DATE'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855382830889813)
,p_name=>'P14_TARGET_VALUE'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855410532889814)
,p_name=>'P14_CURRENT_PROGRESS'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855625690889816)
,p_name=>'P14_SUGGESTION_ID'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38893855714540889817)
,p_name=>'P14_HABIT_CATEGORY_ID'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(38671538830167586227)
,p_computation_sequence=>10
,p_computation_item=>'P14_HABITS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''The AI is restricted to suggest habits from the following list whilst keeping the users interests in mind: '' || ',
'       LISTAGG(''Suggestion ID: '' || habit_category_id || '', Category: '' || habit_category_name || '', Activity: '' || actividad || '', Measurement: '' || medida, chr(10) || chr(13)) ',
'       WITHIN GROUP (ORDER BY habit_category_id) AS habit_list',
'FROM HABIT_CATEGORIES_INVENTORY;',
''))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(38671536979552586208)
,p_computation_sequence=>10
,p_computation_item=>'P14_CONTEXT'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ''Based on the habits and preferences of the user, please suggest personalized habits to improve their mental health and general well-being.'' || chr(10) || chr(13) ||',
'       ''Name: '' || nombre || chr(10) || chr(13) ||',
'       ''Birthdate: '' || TO_CHAR(fecha_nacimiento, ''MM/DD/YYYY'') || chr(10) || chr(13) ||',
'       ''Sex: '' || sexo || chr(10) || chr(13) ||',
'       ''Height: '' || altura || chr(10) || chr(13) ||',
'       ''Weight: '' || peso || chr(10) || chr(13) ||',
'       CASE ',
'           WHEN tiene_diagnostico = 0 THEN ''No mental health diagnosis.'' ',
'           WHEN tiene_diagnostico = 1 THEN ''Mental health diagnosis: '' || diagnostico_especificacion',
'       END as prompt_context',
'FROM USERS',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38835030073787984104)
,p_name=>'Sumbit_DA'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38671539243470586231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38835030152023984105)
,p_event_id=>wwv_flow_imp.id(38835030073787984104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'SUBMIT'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_initial_prompt varchar2(4000) := :P14_INITIAL_PROMPT; -- Get the value from the APEX page item',
'begin',
'    update USERS',
'       set initial_prompt = v_initial_prompt',
'     where user_id = 1;',
'',
'    commit;',
'end;',
''))
,p_attribute_02=>'P14_INITIAL_PROMPT'
,p_attribute_03=>'P14_INITIAL_PROMPT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38835030357480984107)
,p_name=>'JS_trigger'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38671539243470586231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38835030403164984108)
,p_event_id=>wwv_flow_imp.id(38835030357480984107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'trigger'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'processAIResponse()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38893854235593889802)
,p_event_id=>wwv_flow_imp.id(38835030357480984107)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_user_id NUMBER := :x01; -- User ID passed from JavaScript',
'    v_suggestion_id NUMBER := :x02; -- Habit ID passed from JavaScript',
'    v_habit_category_id VARCHAR2(50) := :x03; -- Category ID passed from JavaScript',
'    v_frequency VARCHAR2(50) := :x04; -- Frequency passed from JavaScript',
'    v_start_date DATE := TO_DATE(:x05, ''YYYY-MM-DD''); -- Start date passed from JavaScript',
'    v_end_date DATE := TO_DATE(:x06, ''YYYY-MM-DD''); -- End date passed from JavaScript',
'    v_target_value NUMBER := :x07; -- Target value passed from JavaScript',
'    v_current_progress NUMBER := :x08; -- Current progress passed from JavaScript',
'BEGIN',
'    -- Debug log for values received',
'    apex_debug.message(''Received suggestion_id: '' || v_suggestion_id);',
'    apex_debug.message(''Received start_date: '' || TO_CHAR(v_start_date, ''YYYY-MM-DD''));',
'    apex_debug.message(''Received end_date: '' || TO_CHAR(v_end_date, ''YYYY-MM-DD''));',
'',
'    -- Insert the habit suggestion into the database',
'    INSERT INTO habit_suggestions (',
'        user_id, ',
'        suggestion_id,',
'        habit_category_id,',
'        frequency, ',
'        start_date, ',
'        end_date, ',
'        isActive,',
'        target_value,',
'        current_progress',
'    ) VALUES (',
'        v_user_id, ',
'        v_suggestion_id, -- Use passed suggestion_id instead of sequence',
'        v_habit_category_id,',
'        NVL(v_frequency, ''daily''),  -- Default to ''daily'' if NULL',
'        v_start_date,',
'        v_end_date,',
'        ''1'', -- Mark the habit as active by default',
'        v_target_value,',
'        v_current_progress',
'    );',
'',
'    -- Optionally, log success message',
'    apex_debug.message(''Habit saved for user '' || v_user_id || '' with habit ID '' || v_suggestion_id);',
'END;',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_build_option_id=>wwv_flow_imp.id(38505192785322204626)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38893855867726889818)
,p_name=>'FIllBase'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38671539243470586231)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38893855933378889819)
,p_event_id=>wwv_flow_imp.id(38893855867726889818)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'INSERT INTO HABIT_SUGGESTIONS (SUGGESTION_ID, USER_ID, HABIT_CATEGORY_ID, FREQUENCY, START_DATE, END_DATE, TARGET_VALUE, CURRENT_PROGRESS)',
'VALUES (habit_suggestions_seq.NEXTVAL, ',
'        :P14_USER_ID,',
'        :P14_HABIT_CATEGORY_ID, ',
'        :P14_FREQUENCY, ',
'        TO_DATE(:P14_START_DATE, ''MM/DD/YYYY''), ',
'        TO_DATE(:P14_END_DATE, ''MM/DD/YYYY''), ',
'        :P14_TARGET_VALUE, ',
'        :P14_CURRENT_PROGRESS);'))
,p_attribute_02=>'P14_HABITS,P14_USER_ID,P14_HABIT_CATEGORY_ID,P14_SUGGESTION_ID,P14_FREQUENCY,P14_START_DATE,P14_END_DATE,P14_TARGET_VALUE,P14_CURRENT_PROGRESS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38835030259155984106)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'LOAD_HABIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_user_id NUMBER := :x01; -- User ID passed from JavaScript',
'    v_suggestion_id NUMBER := :x02; -- Habit ID passed from JavaScript',
'    v_habit_category_id VARCHAR(50) := :x03;',
'    v_frequency VARCHAR2(50) := :x04; -- Frequency passed from JavaScript',
'    v_start_date DATE := TO_DATE(:x05, ''YYYY-MM-DD''); -- Start date passed from JavaScript',
'    v_end_date DATE := TO_DATE(:x06, ''YYYY-MM-DD''); -- End date passed from JavaScript',
'    v_target_value NUMBER := :x07;',
'    V_current_progress NUMBER := :x08;',
'',
'BEGIN',
'    -- Debug log for values received',
'    apex_debug.message(''Received suggestion_id: '' || v_suggestion_id);',
'',
'    -- Insert the habit suggestion into the database',
'    INSERT INTO habit_suggestions (',
'        user_id, ',
'        SUGGESTION_ID,',
'        habit_category_id,',
'        frequency, ',
'        start_date, ',
'        end_date, ',
'        isActive,',
'        target_value,',
'        current_progress',
'    ) VALUES (',
'        v_user_id, ',
'        habit_suggestions_seq.NEXTVAL,',
'        apex_application.g_x03,',
'        TO_DATE(apex_application.g_x05, ''MM/DD/YYYY''),',
'        TO_DATE(apex_application.g_x06, ''MM/DD/YYYY''),',
'        ''1'', -- Mark the habit as active by default',
'        apex_application.g_x07,',
'        apex_application.g_x08',
'    );',
'    ',
'    -- Optionally, you can log or return a success message',
'    apex_debug.message(''Habit saved for user '' || apex_application.g_x01 || '' with habit ID '' || apex_application.g_x02);',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38671539243470586231)
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
,p_internal_uid=>38835030259155984106
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38671539464428586233)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(38671539331711586232)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form INITIAL PROMPT ENIGNE'
,p_internal_uid=>38671539464428586233
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38893855548783889815)
,p_process_sequence=>20
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_region_id=>wwv_flow_imp.id(38671539331711586232)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SAVE_HABIT'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_suggestion_id NUMBER := :P14_SUGGESTION_ID;',
'    v_habit_category_id NUMBER := :P14_HABIT_CATEGORY_ID;',
'    v_frequency VARCHAR2(100) := :P14_FREQUENCY;',
'    v_start_date DATE := TO_DATE(:P14_START_DATE, ''MM/DD/YYYY'');',
'    v_end_date DATE := TO_DATE(:P14_END_DATE, ''MM/DD/YYYY'');',
'    v_target_value NUMBER := :P14_TARGET_VALUE;',
'    v_current_progress NUMBER := :P14_CURRENT_PROGRESS;',
'BEGIN',
'    -- Insert the habit suggestion into the habit_suggestions table',
'    INSERT INTO habit_suggestions (',
'        suggestion_id,',
'        habit_category_id,',
'        frequency,',
'        start_date,',
'        end_date,',
'        target_value,',
'        current_progress,',
'        isActive',
'    ) VALUES (',
'        v_suggestion_id,',
'        v_habit_category_id,',
'        v_frequency,',
'        v_start_date,',
'        v_end_date,',
'        v_target_value,',
'        v_current_progress,',
'        1  -- Always set isActive to 1',
'    );',
'    ',
'    -- Optionally, display a success message or return a success result',
'    apex_debug.message(''Habit saved successfully.'');',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
,p_internal_uid=>38893855548783889815
);
wwv_flow_imp.component_end;
end;
/
