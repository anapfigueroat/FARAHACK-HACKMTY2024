prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Start Journey - Create User'
,p_alias=>'CREATE-USER-1'
,p_step_title=>'Create User - 1'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Region,',
't-Region-header,',
't-Region-headerItems,',
' t-Region-headerItems--title{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(-15deg, #7023bf 1%, #ffffff 22%);',
'}',
'',
'.t-Region-header {',
'    padding-top: 70px;',
'    background-color: transparent; /* Set background to transparent */',
'    text-align: center; /* Center the text */',
'    padding: 20px; /* Optional: Add some padding for better spacing */',
'}',
'',
'.t-Region-headerItems--title {',
'',
'    display: inline-block; /* Make the title block inline to center it */',
'    font-size: 3rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'}',
'',
'.t-Button{',
'    background-color: transparent;',
'    border: solid 1px #bf2324;',
'    border-radius: 10px;',
'    box-shadow: none !important;',
'    color: #bf2324;',
'    font-size: 15px;',
'    margin-bottom: 30px;',
'}',
'',
'.t-Button--icon{',
'    border: none !important;',
'    font-size: 30px;',
'    color: #7f58fd;',
'}',
'',
'.t-Button--tiny {',
'    font-size: 1em; /* Font size */',
'    margin-left: -80%; /* Moves the button to the left */',
'    margin-top: 20px; /* Adjusts the vertical position */',
'    padding-top: 100px; /* Adds space inside the button at the top */',
'}',
''))
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38743854471543098712)
,p_plug_name=>'Welcome'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38505896682520204680)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<html lang="en">',
'  <head>',
'    <meta charset="UTF-8" />',
'    <meta name="viewport" content="width=device-width, initial-scale=1.0" />',
'    <title>Centered Title and Subtitle</title>',
'    <style>',
'      body {',
'        display: flex;',
'        flex-direction: column;',
'        align-items: center;',
'        justify-content: top;',
'        margin: 0;',
'        font-family: Arial, sans-serif;',
'        text-align: center; /* Center text */',
'      }',
'      h2 {',
'        font-size: 2.5em;',
'      }',
'      h3 {',
'        color: #a97bd9;',
'        font-size: 1.2em; /* Subtitle size */',
'        margin: 0 0 100px 0; /* Margin for spacing */',
'      }',
'      hr {',
'            margin-top: -20%;',
'            width: 80%; /* Width of the line */',
'            border: 1px solid #f1e9f9; /* Change this color for the line */',
'            ',
'        }',
'    </style>',
'  </head>',
'  <body>',
'    <h3>',
unistr('      We\2019re thrilled to have you here. As you embark on this exciting journey of'),
'      self-improvement, we want to guide you through the process of creating',
'      your account and unlocking the power of AI technology to personalize your',
'      habits.',
'    </h3>',
'    <hr />',
'  </body>',
'</html>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38743854876926098716)
,p_button_sequence=>30
,p_button_name=>'startjourney'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Start Journey'
,p_button_redirect_url=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-circle-arrow-out-east'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38743855053657098718)
,p_button_sequence=>50
,p_button_name=>'GoBack'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny:t-Button--simple:t-Button--iconLeft:t-Button--gapTop'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_image_alt=>'Back'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_grid_new_row=>'Y'
,p_grid_row_css_classes=>'margin-bottom: -30px'
);
wwv_flow_imp.component_end;
end;
/
