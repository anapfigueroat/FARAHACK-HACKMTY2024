prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>'HealthConditions - Create User'
,p_alias=>'HEALTHCONDITIONS'
,p_step_title=>'HealthConditions'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Custom CSS for Login Page Button */',
'',
'body {',
'        display: flex;',
'        flex-direction: column;',
'        align-items: center;',
'        justify-content: top;',
'        margin: 0;',
'        font-family: Arial, sans-serif;',
'        text-align: center; /* Center text */',
'    }',
'',
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 7px 15px;',
'    border: solid 1px #7023bf;',
'    font-size: 12px;',
'    cursor: pointer;',
'}',
'',
'.custom-login-button:hover {',
'    background-color: #7f58fd;',
'    color: #ffffff;',
'}',
'',
'.custom-singup-button {',
'    background-color: #7023bf;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button:hover {',
'    background-color: #ffffff;',
'    color: #7023bf;',
'}',
'',
'.t-Login-containerBody{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Login-region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(18deg, #7023bf 1%, #ffffff 23%, #ffffff 90%, #7f58fd 99%);',
'}',
'',
'.t-Form-fieldContainer{',
' background-color: transparent;',
'    border-radius: 10px;',
'}',
'',
'/* Styles for the login form */',
'',
'/* Remove background colors from form elements */ ',
'',
'.text_field,',
'.password {',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'    height: 40px;',
'     /* Remove background colors */',
'}',
'',
'.apex-item-icon {',
'    color: #7f58fd !important; /* Set color to purple */',
'}',
'.t-Region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Region-header{',
'    font-size: 1.8rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'}',
'',
'.t-Button{',
'    box-shadow: none !important;',
'}',
'',
'.t-Button--icon{',
'    border: none !important;',
'    font-size: 30px;',
'    color: #7f58fd;',
'}',
'',
'.t-Button--tiny {',
'     background-color: transparent;',
'    font-size: 1em; /* Font size */',
'    margin-left: -80%; /* Moves the button to the left */',
'    margin-top: 20px; /* Adjusts the vertical position */',
'}',
'',
'.a-Button{',
'    color: white;',
'    background-color: #7023bf;',
'    border: none;',
'}',
'',
'.apex-item-datepicker{',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'}',
'',
'.t-Region-body{',
'    color: #7f58fd;',
'}',
'',
'.t-Form-labelContainer{',
'    color: #7023bf;',
'}',
'',
'.js-show-label{',
'    color: #7023bf;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38766217797514611336)
,p_plug_name=>'New'
,p_title=>'Any Health Condition?'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38505896682520204680)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'TABLE'
,p_query_table=>'USERS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This information helps us and our AI better understand ',
'your unique situation, allowing us to provide you with ',
'the most accurate and personalized recommendations. ',
'Your privacy and comfort are our ',
'top priorities, and all information will be kept confidential.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38766218991179611348)
,p_button_sequence=>30
,p_button_name=>'Prefernottoshare'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_image_alt=>'Prefer not to share'
,p_button_redirect_url=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'custom-login-button'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38771725479899775404)
,p_button_sequence=>40
,p_button_name=>'Return'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_image_alt=>'Back'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38766219014618611349)
,p_button_sequence=>50
,p_button_name=>'Next'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_redirect_url=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'custom-singup-button'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38743857020169098738)
,p_name=>'P21_DIAGNOSTICO_ESPECIFICACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38766217797514611336)
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Mood disorders;Mood disorders,Anxiety disorders;Anxiety disorders,Obesity;Obesity,Hypertension ;Hypertension ,Diabetes;Diabetes'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38766217909381611338)
,p_name=>'P21_USER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38766217797514611336)
,p_item_source_plug_id=>wwv_flow_imp.id(38766217797514611336)
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38881876575117178714)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38766219014618611349)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38881876632955178715)
,p_event_id=>wwv_flow_imp.id(38881876575117178714)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE users',
'       SET tiene_diagnostico = 1,',
'           diagnostico_especificacion = :P21_DIAGNOSTICO_ESPECIFICACION',
'         ',
'     WHERE user_id = 220;',
'',
'    COMMIT;',
'END;',
''))
,p_attribute_02=>'P21_TIENE_DIAGNOSTICO,,P21_DIAGNOSTICO_ESPECIFICACION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38881876747381178716)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38766218991179611348)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38881876899825178717)
,p_event_id=>wwv_flow_imp.id(38881876747381178716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'    UPDATE users',
'        SET tiene_diagnostico = 0',
'',
'    WHERE user_id = 220;',
'',
'    COMMIT;',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38766217853808611337)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(38766217797514611336)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form HealthConditions - Create User'
,p_internal_uid=>38766217853808611337
);
wwv_flow_imp.component_end;
end;
/
