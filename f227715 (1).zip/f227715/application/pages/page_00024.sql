prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>24
,p_name=>'Sign Up - Create Account'
,p_alias=>'SIGN-UP-CREATE-ACCOUNT'
,p_step_title=>'Sign Up - Create Account'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Custom CSS for Login Page Button */',
'',
'body {',
'        display: flex;',
'        flex-direction: column;',
'        align-items: center;',
'        justify-content: top;',
'        margin: 0;',
'        font-family: Arial, sans-serif;',
'        text-align: center; /* Center text */',
'    }',
'',
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-login-button:hover {',
'    background-color: #7f58fd;',
'    color: #ffffff;',
'}',
'',
'.custom-singup-button {',
'    background-color: #7023bf;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button:hover {',
'    background-color: #ffffff;',
'    color: #7023bf;',
'}',
'',
'.t-Login-containerBody{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Login-region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(15deg, #7023bf 1%, #ffffff 23%, #ffffff 93%, #7f58fd 99%);',
'}',
'',
'.t-Form-fieldContainer{',
' background-color: transparent;',
'    border-radius: 10px;',
'}',
'',
'/* Styles for the login form */',
'',
'/* Remove background colors from form elements */ ',
'',
'.text_field,',
'.password {',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'    height: 40px;',
'     /* Remove background colors */',
'}',
'',
'.apex-item-icon {',
'    color: #7f58fd !important; /* Set color to purple */',
'}',
'.t-Region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Region-header{',
'    font-size: 2.5rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'}',
'',
'.t-Button{',
'    box-shadow: none !important;',
'}',
'',
'.t-Button--icon{',
'    border: none !important;',
'    font-size: 30px;',
'    color: #7f58fd;',
'}',
'',
'.t-Button--tiny {',
'    background-color: transparent;',
'    font-size: 1em; /* Font size */',
'    margin-left: -80%; /* Moves the button to the left */',
'    margin-top: 20px; /* Adjusts the vertical position */',
'    padding-top: 150px; /* Adds space inside the button at the top */',
'}'))
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38848186973875071621)
,p_plug_name=>'CreateUser'
,p_title=>'Creating Account'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38505896682520204680)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'USERS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38848188258030071634)
,p_button_sequence=>40
,p_button_name=>'CreateAccount'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Next'
,p_button_redirect_url=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.:::'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'custom-singup-button'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38848188386012071635)
,p_button_sequence=>50
,p_button_name=>'GoBack'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--tiny:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_image_alt=>'Back'
,p_button_redirect_url=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38848187133657071623)
,p_name=>'P24_USER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38848186973875071621)
,p_item_source_plug_id=>wwv_flow_imp.id(38848186973875071621)
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38848187526877071627)
,p_name=>'P24_EMAIL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38848186973875071621)
,p_item_source_plug_id=>wwv_flow_imp.id(38848186973875071621)
,p_placeholder=>'Username'
,p_source=>'EMAIL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(38505967450453204717)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38848187686263071628)
,p_name=>'P24_PASSWORD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(38848186973875071621)
,p_item_source_plug_id=>wwv_flow_imp.id(38848186973875071621)
,p_placeholder=>'Password'
,p_source=>'PASSWORD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_field_template=>wwv_flow_imp.id(38505967450453204717)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38859867030466798535)
,p_name=>'New_2'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38848188258030071634)
,p_condition_element=>'P24_EMAIL'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38859867161696798536)
,p_event_id=>wwv_flow_imp.id(38859867030466798535)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    insert into users (',
'        user_id,',
'        email,',
'        password',
'    ) ',
'    values (',
'        user_id_seq.nextval,',
'        :P24_EMAIL,',
'        :P24_PASSWORD);',
'',
'    ',
'end;'))
,p_attribute_02=>'P24_EMAIL,,P24_PASSWORD'
,p_attribute_03=>'P24_USER_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P24_PASSWORD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38848189296391071644)
,p_name=>'New_1'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P24_EMAIL,P24_PASSWORD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38848189397530071645)
,p_event_id=>wwv_flow_imp.id(38848189296391071644)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    insert into users (',
'        user_id,',
'        email,',
'        password',
'    ) ',
'    values (',
'        user_id_seq.nextval,',
'        :P24_EMAIL,',
'        :P24_PASSWORD);',
'',
'     apex_util.redirect_url(''f?p='' || :APP_ID || '':19:'' || :APP_SESSION);',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38848189488291071646)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SignUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    insert into users (',
'        user_id,',
'        email,',
'        password',
'    ) ',
'    values (',
'        user_id_seq.nextval,',
'        :P24_EMAIL,',
'        :P24_PASSWORD);',
'',
'     apex_util.redirect_url(''f?p='' || :APP_ID || '':19:'' || :APP_SESSION);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38848189488291071646
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38848187081390071622)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(38848186973875071621)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Sign Up - Create Account'
,p_internal_uid=>38848187081390071622
);
wwv_flow_imp.component_end;
end;
/
