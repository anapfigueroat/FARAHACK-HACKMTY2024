prompt --application/pages/page_00037
begin
--   Manifest
--     PAGE: 00037
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>37
,p_name=>'Tracking Your Journey'
,p_alias=>'DAILY-TRACKING2'
,p_step_title=>'Tracking Your Journey'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38867789927351027725)
,p_plug_name=>'Tracking Your Journey'
,p_title=>'Tracking Your Journey'
,p_component_template_options=>'#DEFAULT#'
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(38505193303684204626)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38505971835402204720)
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38867791527865027862)
,p_plug_name=>'Tracking Your Journey'
,p_title=>'   '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38505896682520204680)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'DAILY_TRACKING'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38867794979337027865)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_button_name=>'SAVE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:::'
,p_button_condition=>'P37_ENTRY_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38867793960450027864)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38867795356265027865)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P37_ENTRY_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38867794510325027865)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P37_ENTRY_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38867795601481027866)
,p_branch_name=>'Go To Page 1'
,p_branch_action=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38829739701461828050)
,p_name=>'P37_ENERGY'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_prompt=>'Energy'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ENERGY_LEVEL, ENERGY_ID',
'FROM ENERGY_INVENTORY',
'WHERE ENERGY_LEVEL IS NOT NULL',
'ORDER BY ENERGY_LEVEL;',
'',
''))
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--boldDisplay'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38867791810831027863)
,p_name=>'P37_ENTRY_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_item_source_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_source=>'ENTRY_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38867792257359027863)
,p_name=>'P37_USER_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_item_source_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38867792670219027864)
,p_name=>'P37_ENTRY_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_item_source_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_prompt=>'Entry Date'
,p_source=>'ENTRY_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871316090610165501)
,p_name=>'P37_MOOD'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_prompt=>'Mood'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT MOOD_NAME, MOOD_ID',
'FROM MOOD_INVENTORY',
'WHERE MOOD_NAME IS NOT NULL',
'ORDER BY MOOD_NAME;',
'',
''))
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871316124461165502)
,p_name=>'P37_SLEEP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_prompt=>'Sleep'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SLEEP_QUALITY_NAME, SLEEP_QUALITY_ID ',
'FROM SLEEP_QUALITY_INVENTORY WHERE SLEEP_QUALITY_NAME IS NOT NULL',
'ORDER BY SLEEP_QUALITY_NAME',
''))
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871316246696165503)
,p_name=>'P37_EXERCISE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_prompt=>'Exercise'
,p_display_as=>'NATIVE_SELECT_MANY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EXERCISE_NAME, EXERCISE_ID',
'FROM EXERCISE_INVENTORY',
'ORDER BY EXERCISE_NAME;',
''))
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_09=>'0'
,p_attribute_13=>'Y'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871316329078165504)
,p_name=>'P37_SOCIAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_prompt=>'Social'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT INTERACTION_TYPE, SOCIAL_INTERACTION_ID ',
'FROM ',
'SOCIAL_INTERACTION_INVENTORY',
'WHERE INTERACTION_TYPE IS NOT NULL',
'ORDER BY INTERACTION_TYPE',
''))
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871316582984165506)
,p_name=>'P37_TRACK_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38867791527865027862)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38871316426185165505)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Submission'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   v_entry_id NUMBER; -- Variable to store the generated ENTRY_ID (TRACK_ID)',
'BEGIN',
'   -- Step 1: Insert into DAILY_TRACKING and capture the generated ENTRY_ID (which will act as TRACK_ID)',
'   INSERT INTO DAILY_TRACKING ',
'      (ENTRY_ID, USER_ID, ENTRY_DATE) ',
'   VALUES ',
'      (entry_id_seq.NEXTVAL, :P37_USER_ID, SYSDATE)',
'   RETURNING ENTRY_ID INTO v_entry_id; -- Capture the ENTRY_ID generated in the DAILY_TRACKING table',
'   ',
'   -- Step 2: Store the TRACK_ID (which is the ENTRY_ID) in session state for use in the next process',
'   APEX_UTIL.SET_SESSION_STATE(''P37_TRACK_ID'', v_entry_id);  -- Store TRACK_ID in P37_TRACK_ID',
'END;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38871316426185165505
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38867796555654027867)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Daily Tracking'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   v_track_id NUMBER := :P37_TRACK_ID; -- Retrieve TRACK_ID from session state (stored in the Submission process)',
'BEGIN',
'   -- Insert Energy Tracking if ENERGY is not NULL',
'   IF :P37_ENERGY IS NOT NULL THEN',
'      INSERT INTO DAILY_ENERGY_TRACKING (TRACK_ID, ENTRY_ID, ENERGY_ID)',
'      VALUES (v_track_id, v_track_id, :P37_ENERGY); -- Use v_track_id for both TRACK_ID and ENTRY_ID',
'   END IF;',
'',
'   -- Insert Mood Tracking if MOOD is not NULL',
'   IF :P37_MOOD IS NOT NULL THEN',
'      INSERT INTO DAILY_MOOD_TRACKING (TRACK_ID, ENTRY_ID, MOOD_ID)',
'      VALUES (v_track_id, v_track_id, :P37_MOOD); -- Use v_track_id for both TRACK_ID and ENTRY_ID',
'   END IF;',
'',
'   -- Insert Sleep Quality Tracking if SLEEP_QUALITY is not NULL',
'   IF :P37_SLEEP IS NOT NULL THEN',
'      INSERT INTO DAILY_SLEEP_QUALITY_TRACKING (TRACK_ID, ENTRY_ID, SLEEP_QUALITY_ID)',
'      VALUES (v_track_id, v_track_id, :P37_SLEEP); -- Use v_track_id for both TRACK_ID and ENTRY_ID',
'   END IF;',
'',
'   -- Insert Social Interaction Tracking if SOCIAL_INTERACTION is not NULL',
'   IF :P37_SOCIAL IS NOT NULL THEN',
'      INSERT INTO DAILY_SOCIAL_INTERACTION_TRACKING (TRACK_ID, ENTRY_ID, SOCIAL_INTERACTION_ID)',
'      VALUES (v_track_id, v_track_id, :P37_SOCIAL); -- Use v_track_id for both TRACK_ID and ENTRY_ID',
'   END IF;',
'',
'   -- Insert Exercise Tracking if EXERCISE is not NULL',
'   IF :P37_EXERCISE IS NOT NULL THEN',
'      INSERT INTO DAILY_EXERCISE_TRACKING (TRACK_ID, ENTRY_ID, EXERCISE_ID)',
'      VALUES (v_track_id, v_track_id, :P37_EXERCISE); -- Use v_track_id for both TRACK_ID and ENTRY_ID',
'   END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38867796555654027867
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38867796161429027866)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(38867791527865027862)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Daily Tracking'
,p_internal_uid=>38867796161429027866
);
wwv_flow_imp.component_end;
end;
/
