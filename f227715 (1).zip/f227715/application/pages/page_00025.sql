prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>25
,p_name=>'Home'
,p_alias=>'HOME1'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-login-button:hover {',
'    background-color: #7f58fd;',
'    color: #ffffff;',
'}',
'',
'.custom-singup-button {',
'    background-color: #7023bf;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38771727911410775429)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Form--standardPadding:margin-top-lg'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(38505837143081204650)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_CATEGORY_NAME, ACTIVIDAD',
'FROM HABIT_CATEGORIES_INVENTORY;',
'',
'',
''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_ajax_items_to_submit=>'HABIT_CATEGORY_NAME,,ACTIVIDAD'
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'supplemental_info_column', 'ACTIVIDAD',
  'text_column', 'HABIT_CATEGORY_NAME')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38807030344660056740)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38505909084587204686)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38505193303684204626)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38505971835402204720)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38881880112125178750)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:margin-top-lg'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38505837143081204650)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select ',
'    hci.habit_category_name,   -- Category name',
'    hci.actividad,             -- Specific activity',
'    hci.medida,                -- Measurement unit',
'    hs.frequency,              -- Frequency of the habit',
'    to_char(hs.start_date, ''MM/DD/YYYY'') as start_date,   -- Formatted start date',
'    to_char(hs.end_date, ''MM/DD/YYYY'') as end_date       -- Formatted end date',
'  from ',
'    habit_suggestions hs',
'  join ',
'    habit_categories_inventory hci',
'    on hs.habit_category_id = hci.habit_category_id',
' ',
' order by ',
'    hs.start_date      -- Optional: Order by the start date'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'HABIT_CATEGORY_NAME,,ACTIVIDAD'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(38966773922473496201)
,p_region_id=>wwv_flow_imp.id(38881880112125178750)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'HABIT_CATEGORY_NAME'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'ACTIVIDAD'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="horizontal-layout" style="display: flex; align-items: center;">',
'  &START_DATE. <p style="margin: 0 10px;"> - </p> &END_DATE.',
'</div>'))
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ACTIVIDAD'
,p_pk2_column_name=>'HABIT_CATEGORY_NAME'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38881879147661178740)
,p_button_sequence=>10
,p_button_name=>'AddTask'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_image_alt=>'Add Task'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'custom-login-button custom-singup-button'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38881876969214178718)
,p_name=>'HABIT_CATEGORY_NAME'
,p_item_sequence=>40
,p_use_cache_before_default=>'NO'
,p_source=>'HABIT_CATEGORY_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38881877057653178719)
,p_name=>'ACTIVIDAD'
,p_item_sequence=>50
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT HABIT_CATEGORY_NAME',
'FROM HABIT_CATEGORIES_INVENTORY;',
''))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'HABIT_CATEGORY_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
