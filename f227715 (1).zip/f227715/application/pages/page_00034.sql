prompt --application/pages/page_00034
begin
--   Manifest
--     PAGE: 00034
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>34
,p_name=>'Login-Oficial'
,p_alias=>'LOGIN-OFICIAL'
,p_step_title=>'Login-Oficial'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Custom CSS for Login Page Button */',
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-login-button:hover {',
'    background-color: #7f58fd;',
'    color: #ffffff;',
'}',
'',
'.custom-singup-button {',
'    background-color: #7023bf;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button:hover {',
'    background-color: #ffffff;',
'    color: #7023bf;',
'}',
'',
'.t-Login-region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(15deg, #7023bf 1%, #ffffff 22%);',
'}',
'',
'.t-Form-fieldContainer{',
' background-color: transparent;',
'    border-radius: 10px;',
'}',
'',
'/* Styles for the login form */',
'',
'/* Remove background colors from form elements */ ',
'',
'.text_field,',
'.t-Login-body',
'.custom-login-button, ',
'.password {',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'     /* Remove background colors */',
'}',
'',
'.apex-item-icon {',
'    color: #7f58fd !important; /* Set color to purple */',
'}',
'',
'/* Increase the font size of the heading */',
'.t-Login-title {',
'    font-size: 3rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'}',
'',
'/* Make the checkbox background transparent and set the border color to purple */',
'.apex-item-single-checkbox {',
'    color: #7f58fd;',
'}',
'',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38743855521911098723)
,p_plug_name=>'Habits'
,p_title=>'Habits'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerTitle js-removeLandmark:js-headingLevel-6'
,p_plug_template=>wwv_flow_imp.id(38505891446923204677)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38743856697273098734)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38743855521911098723)
,p_button_name=>'SINGUP'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sing Up'
,p_button_position=>'NEXT'
,p_button_css_classes=>'custom-singup-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38743856720511098735)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38743855521911098723)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Login'
,p_button_position=>'NEXT'
,p_button_css_classes=>'custom-login-button'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38743856399711098731)
,p_name=>'USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38743855521911098723)
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_tag_attributes=>'100'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38743856493618098732)
,p_name=>'PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38743855521911098723)
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38743856571788098733)
,p_name=>'P34_NEW_2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38743855521911098723)
,p_prompt=>'Remember me'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
