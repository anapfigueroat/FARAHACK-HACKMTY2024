prompt --application/pages/page_00023
begin
--   Manifest
--     PAGE: 00023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>23
,p_name=>'FreeTime - Create User'
,p_alias=>'FREETIME-CREATE-USER'
,p_step_title=>'FreeTime - Create User'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Custom CSS for Login Page Button */',
'',
'body {',
'        display: flex;',
'        flex-direction: column;',
'        align-items: center;',
'        justify-content: top;',
'        margin: 0;',
'        font-family: Arial, sans-serif;',
'        text-align: center; /* Center text */',
'    }',
'',
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 7px 15px;',
'    border: solid 1px #7023bf;',
'    font-size: 12px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button {',
'    background-color: #ffffff;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button:hover {',
'    background-color: #ffffff;',
'    color: #7023bf;',
'}',
'',
'.t-Login-containerBody{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Login-region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(18deg, #7023bf 1%, #ffffff 23%, #ffffff 90%, #7f58fd 99%);',
'}',
'',
'.t-Form-fieldContainer{',
' background-color: transparent;',
'    border-radius: 10px;',
'}',
'',
'/* Styles for the login form */',
'',
'/* Remove background colors from form elements */ ',
'',
'.text_field,',
'.password {',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'    height: 40px;',
'     /* Remove background colors */',
'}',
'',
'.apex-item-icon {',
'    color: #ffffff !important; /* Set color to purple */',
'}',
'.t-Region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-Region-header{',
'    font-size: 2.4rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'}',
'',
'.t-Button{',
'    box-shadow: none !important;',
'}',
'',
'.t-Button--icon{',
'    border: none !important;',
'    font-size: 30px;',
'    color: #7f58fd;',
'}',
'',
'.t-Button--tiny {',
'     background-color: transparent;',
'    font-size: 1em; /* Font size */',
'    margin-left: -80%; /* Moves the button to the left */',
'    margin-top: 20px; /* Adjusts the vertical position */',
'}',
'',
'.a-Button{',
'    color: white;',
'    background-color: #7023bf;',
'    border: none;',
'}',
'',
'.t-Region-body{',
'    color: #7f58fd;',
'}',
'',
'',
'.number_field{',
'    margin: 30px;',
'    padding: 20px;',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 2px #7023bf;',
'    height: 40px;',
'     /* Remove background colors */',
'}'))
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38871316687489165507)
,p_plug_name=>'New'
,p_title=>'Free time'
,p_icon_css_classes=>'fa-clock-o'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(38505896682520204680)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'USERS'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Please let us know how much free time ',
'you believe you have available ',
'to dedicate to achieving your goals.'))
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38743857118635098739)
,p_button_sequence=>20
,p_button_name=>'submit'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(38505970399409204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'custom-singup-button'
,p_icon_css_classes=>'fa-upload'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871316934484165510)
,p_name=>'P23_USER_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38871316687489165507)
,p_item_source_plug_id=>wwv_flow_imp.id(38871316687489165507)
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38871318035875165521)
,p_name=>'P23_FREE_TIME'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(38871316687489165507)
,p_item_source_plug_id=>wwv_flow_imp.id(38871316687489165507)
,p_placeholder=>'Enter number of hours'
,p_source=>'FREE_TIME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>40
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38966774092895496202)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38743857118635098739)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38966774199965496203)
,p_event_id=>wwv_flow_imp.id(38966774092895496202)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE users',
'       SET free_time = :P23_FREE_TIME',
'     WHERE user_id = 220;',
'',
'    COMMIT;',
'END;',
''))
,p_attribute_02=>'P23_FREE_TIME'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38871318163423165522)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'save free time'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'   -- Update the free time for the current user',
'   UPDATE USERS',
'   SET FREE_TIME = :PXX_FREE_TIME -- Replace XX with your page number',
'   WHERE USER_ID = :APP_USER; -- Assuming :APP_USER holds the current user''s ID',
'',
'   -- Optional: Add a success message',
'   APEX_UTIL.SET_SESSION_STATE(''FREE_TIME_UPDATED'', ''Y'');',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38871318163423165522
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38871316718149165508)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(38871316687489165507)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form FreeTime - Create User'
,p_internal_uid=>38871316718149165508
);
wwv_flow_imp.component_end;
end;
/
