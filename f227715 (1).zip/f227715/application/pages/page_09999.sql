prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Login Page'
,p_alias=>'LOGIN'
,p_step_title=>'Habit Tracker - Log In'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Custom CSS for Login Page Button */',
'.custom-login-button {',
'    background-color: transparent;',
'    color: #7023bf;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-login-button:hover {',
'    background-color: #7f58fd;',
'    color: #ffffff;',
'}',
'',
'.custom-singup-button {',
'    background-color: #7023bf;',
'    color: #ffffff;',
'    border-radius: 10px;',
'    padding: 10px 20px;',
'    border: solid 1px #7023bf;',
'    font-size: 16px;',
'    cursor: pointer;',
'}',
'',
'.custom-singup-button:hover {',
'    background-color: #ffffff;',
'    color: #7023bf;',
'}',
'',
'.t-Login-region{',
'    background-color: transparent;',
'    border: none !important;',
'    box-shadow: none !important;',
'}',
'',
'.t-PageBody--login {',
'background: linear-gradient(15deg, #7023bf 1%, #ffffff 22%);',
'}',
'',
'.t-Form-fieldContainer{',
' background-color: transparent;',
'    border-radius: 10px;',
'}',
'',
'/* Styles for the login form */',
'',
'/* Remove background colors from form elements */ ',
'',
'.text_field,',
'.t-Login-body',
'.custom-login-button, ',
'.password {',
'    background-color: transparent !important;',
'    color: #7f58fd !important;',
'    border: solid 1px #7023bf;',
'     /* Remove background colors */',
'}',
'',
'.apex-item-icon {',
'    color: #7f58fd !important; /* Set color to purple */',
'}',
'',
'/* Increase the font size of the heading */',
'.t-Login-title {',
'    font-size: 3rem; /* Adjust the size as needed */',
'    font-weight: bold; /* Optional: make it bold */',
'    color: #7023bf;',
'}',
'',
'/* Make the checkbox background transparent and set the border color to purple */',
'.apex-item-single-checkbox {',
'    color: #7f58fd;',
'}',
'',
'',
''))
,p_step_template=>wwv_flow_imp.id(38505804783808204633)
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38506087559301204853)
,p_plug_name=>'Habits'
,p_title=>'Habits'
,p_region_css_classes=>'a-pwaPush--subscriptionRegion'
,p_region_template_options=>'#DEFAULT#:t-Login-region--headerTitle js-removeLandmark:js-headingLevel-6'
,p_plug_template=>wwv_flow_imp.id(38505891446923204677)
,p_plug_display_sequence=>10
,p_location=>null
,p_region_image=>'#APP_FILES#icons/App-logo'
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38506089610438204856)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38506087559301204853)
,p_button_name=>'LOGIN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sign In'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.:::'
,p_button_css_classes=>'custom-login-button'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38671536547792586204)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(38506087559301204853)
,p_button_name=>'SIGNUP'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Sign up'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:9999::'
,p_button_css_classes=>'custom-singup-button'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38506088084796204854)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38506087559301204853)
,p_prompt=>'Username'
,p_placeholder=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="username"'
,p_field_template=>wwv_flow_imp.id(38505967450453204717)
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38506088449056204855)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38506087559301204853)
,p_prompt=>'Password'
,p_placeholder=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_tag_attributes=>'autocomplete="current-password"'
,p_field_template=>wwv_flow_imp.id(38505967450453204717)
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38506088847040204855)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38506087559301204853)
,p_prompt=>'Remember username'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_display_when=>'apex_authentication.persistent_cookies_enabled and not apex_authentication.persistent_auth_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(38505967450453204717)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38506089212730204856)
,p_name=>'P9999_PERSISTENT_AUTH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38506087559301204853)
,p_prompt=>'Remember me'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_tag_css_classes=>'custom-login-button'
,p_display_when=>'apex_authentication.persistent_auth_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(38505967450453204717)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38859867647715798541)
,p_name=>'AUTH'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38506089610438204856)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38859867787188798542)
,p_event_id=>wwv_flow_imp.id(38859867647715798541)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    v_user_id users.user_id%type;',
'    v_email    varchar2(100) := :P9999_USERNAME; -- Replace with actual email input',
'    v_password varchar2(100) := :P9999_PASSWORD; -- Replace with actual password input',
'begin',
'    -- Select the user ID based on the provided email and password',
'    select user_id',
'      into v_user_id',
'      from users',
'     where email = v_email',
'       and password = v_password;',
'',
'    -- Set the session state for the USER_ID item',
'    apex_util.set_session_state(''USER_ID'', v_user_id);',
'',
'    dbms_output.put_line(''User ID: '' || v_user_id);',
'    -- Optionally redirect the user to a different page after successful login',
'    --APEX_UTIL.REDIRECT_URL(''f?p=227715:25:'' || 115692495560741);  -- Replace 25 with the desired page number',
'',
'exception',
'    when no_data_found then',
'        -- Raise an error if no matching user is found',
'        raise_application_error(-20001, ''Invalid email or password'');',
'end;',
''))
,p_attribute_02=>'P9999_USERNAME,,P9999_PASSWORD'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38859868283895798547)
,p_name=>'New'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38859868310131798548)
,p_event_id=>wwv_flow_imp.id(38859868283895798547)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_user_id users.user_id%TYPE;',
'BEGIN',
'    -- Validate credentials (email and password)',
'    SELECT user_id INTO v_user_id',
'    FROM users',
'    WHERE email = :P9999_USERNAME',
'      AND password = :P9999_PASSWORD;',
'',
'    -- Set session state for USER_ID (make sure you define USER_ID as a hidden item)',
'    APEX_UTIL.SET_SESSION_STATE(''USER_ID'', v_user_id);',
'    ',
'    -- Optionally, set a global item in session for the user',
'    :USER_ID := v_user_id;',
'',
'    -- Redirect to another page after successful login (like a dashboard)',
'    APEX_UTIL.REDIRECT_URL(''f?p=227715:1'');  -- Replace with the actual page number',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        -- Add an error message for invalid credentials',
'        APEX_ERROR.ADD_ERROR(',
'            p_message => ''Incorrect username or password. Please try again.'',',
'            p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'        );',
'END;'))
,p_attribute_02=>'P9999_USERNAME,,P9999_PASSWORD'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38881875503347178704)
,p_name=>'submit'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38506089610438204856)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_required_patch=>wwv_flow_imp.id(38505192785322204626)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38881875627143178705)
,p_event_id=>wwv_flow_imp.id(38881875503347178704)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38506091892103204858)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38506091892103204858
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38506092320669204858)
,p_page_process_id=>wwv_flow_imp.id(38506091892103204858)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P9999_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38506092853328204858)
,p_page_process_id=>wwv_flow_imp.id(38506091892103204858)
,p_page_id=>9999
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'ITEM'
,p_value=>'P9999_REMEMBER'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38506089933020204856)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38506089933020204856
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38881875708618178706)
,p_page_process_id=>wwv_flow_imp.id(38506089933020204856)
,p_page_id=>9999
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9999_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38881875856067178707)
,p_page_process_id=>wwv_flow_imp.id(38506089933020204856)
,p_page_id=>9999
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9999_PASSWORD'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38881875907367178708)
,p_page_process_id=>wwv_flow_imp.id(38506089933020204856)
,p_page_id=>9999
,p_name=>'p_uppercase_username'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(38881876022555178709)
,p_page_process_id=>wwv_flow_imp.id(38506089933020204856)
,p_page_id=>9999
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38506093738640204859)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38506093738640204859
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38829738360388828036)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Retrieve User ID'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_user_id users.user_id%TYPE;',
'BEGIN',
'    -- Validate user credentials and retrieve the user_id',
'    SELECT user_id',
'    INTO v_user_id',
'    FROM users',
'    WHERE email = :P9999_USERNAME',
'    AND password = :P9999_PASSWORD;',
'',
'    -- Set the session state for the user_id',
'    APEX_UTIL.SET_SESSION_STATE(''P9999_USER_ID'', v_user_id);',
'EXCEPTION',
'    WHEN NO_DATA_FOUND THEN',
'        APEX_ERROR.ADD_ERROR(',
'            p_message => ''Invalid username or password.'',',
'            p_display_location => APEX_ERROR.C_INLINE_IN_NOTIFICATION',
'        );',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(38506089610438204856)
,p_process_success_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Login Successful! Your user ID is: &P9999_USER_ID.',
''))
,p_internal_uid=>38829738360388828036
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38506093323373204858)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>38506093323373204858
);
wwv_flow_imp.component_end;
end;
/
