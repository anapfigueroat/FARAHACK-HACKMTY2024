prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>38424568537946146873
,p_default_application_id=>227715
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FARAHACK'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Daily Tracking'
,p_alias=>'DAILY-TRACKING1'
,p_step_title=>'Daily Tracking'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38506140640679206133)
,p_plug_name=>'Daily Tracking'
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'TABLE'
,p_query_table=>'DAILY_TRACKING'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Daily Tracking'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(38506140715150206133)
,p_name=>'Daily Tracking'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_base_pk1=>'ENTRY_ID'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:RP:P6_ENTRY_ID:\#ENTRY_ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit" class="fa fa-edit" title="Edit"></span>'
,p_owner=>'FELIPE.RAMOS099@GMAIL.COM'
,p_internal_uid=>38506140715150206133
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506141484435206134)
,p_db_column_name=>'ENTRY_ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Entry ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506141856694206135)
,p_db_column_name=>'USER_ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'User'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_named_lov=>wwv_flow_imp.id(38506113124946205563)
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506142274326206135)
,p_db_column_name=>'ENTRY_DATE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Entry Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506142641995206136)
,p_db_column_name=>'MOOD'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Mood'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506143053594206136)
,p_db_column_name=>'ENERGY'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Energy'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506143487368206136)
,p_db_column_name=>'SLEEP_QUALITY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Sleep Quality'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506143838536206136)
,p_db_column_name=>'EXERCISE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Exercise'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506144293023206137)
,p_db_column_name=>'SOCIAL_INTERACTION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Social Interaction'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506144640265206137)
,p_db_column_name=>'HABITOS_DESEADOS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Habitos Deseados'
,p_allow_sorting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'CLOB'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(38506145076981206137)
,p_db_column_name=>'ACTIVIDAD_MENTAL_ACTUAL'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Actividad Mental Actual'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(38506266452244206249)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'385062665'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USER_ID:ENTRY_DATE:MOOD:ENERGY:SLEEP_QUALITY:EXERCISE:SOCIAL_INTERACTION:HABITOS_DESEADOS:ACTIVIDAD_MENTAL_ACTUAL'
,p_sort_column_1=>'USER_ID'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(38506146756425206139)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38505909084587204686)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(38505193303684204626)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(38505971835402204720)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38506145595444206138)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(38506140640679206133)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(38505970297978204719)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:6::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742014500469055210)
,p_name=>'P5_NEW'
,p_item_sequence=>40
,p_prompt=>'New'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742014634476055211)
,p_name=>'P5_NEW_1'
,p_item_sequence=>30
,p_prompt=>'New'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742015726590055222)
,p_name=>'P5_EXERCISE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(38506146756425206139)
,p_prompt=>'New'
,p_source=>'APEX_APPLICATION.G_F02'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742015830637055223)
,p_name=>'P5_MOOD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(38506146756425206139)
,p_prompt=>'New'
,p_source=>'APEX_APPLICATION.G_F01'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742015920273055224)
,p_name=>'P5_SLEEP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(38506146756425206139)
,p_prompt=>'New'
,p_source=>'APEX_APPLICATION.G_F05'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742016099715055225)
,p_name=>'P5_ENERGY'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(38506146756425206139)
,p_prompt=>'New'
,p_source=>'APEX_APPLICATION.G_F03'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38742016155285055226)
,p_name=>'P5_SOCIAL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(38506146756425206139)
,p_prompt=>'New'
,p_source=>'APEX_APPLICATION.G_F04'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Display1;Return1,Display2;Return2'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(38505967794842204718)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38506145842675206138)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(38506140640679206133)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38506146328872206138)
,p_event_id=>wwv_flow_imp.id(38506145842675206138)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(38506140640679206133)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38742016231065055227)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'process form submission'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- First, insert into the daily_tracking table',
'DECLARE',
'  l_entry_id NUMBER; -- Declare a variable to hold the entry_id',
'BEGIN',
'  -- Insert the basic daily tracking entry',
'  INSERT INTO daily_tracking (user_id, entry_date)',
'  VALUES (:APP_USER, SYSDATE)',
'  RETURNING entry_id INTO l_entry_id; -- Store the new entry_id',
'  ',
'  -- Insert into the daily_mood_tracking table',
'  FOR i IN 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'    INSERT INTO daily_mood_tracking (entry_id, mood_id)',
'    VALUES (l_entry_id, APEX_APPLICATION.G_F01(i));',
'  END LOOP;',
'',
'  -- Insert into the daily_exercise_tracking table',
'  FOR i IN 1..APEX_APPLICATION.G_F02.COUNT LOOP',
'    INSERT INTO daily_exercise_tracking (entry_id, exercise_id)',
'    VALUES (l_entry_id, APEX_APPLICATION.G_F02(i));',
'  END LOOP;',
'',
'  -- Insert into the daily_energy_tracking table',
'  FOR i IN 1..APEX_APPLICATION.G_F03.COUNT LOOP',
'    INSERT INTO daily_energy_tracking (entry_id, energy_id)',
'    VALUES (l_entry_id, APEX_APPLICATION.G_F03(i));',
'  END LOOP;',
'',
'  -- Insert into the daily_social_interaction_tracking table',
'  FOR i IN 1..APEX_APPLICATION.G_F04.COUNT LOOP',
'    INSERT INTO daily_social_interaction_tracking (entry_id, social_interaction_id)',
'    VALUES (l_entry_id, APEX_APPLICATION.G_F04(i));',
'  END LOOP;',
'',
'  -- Insert into the daily_sleep_quality_tracking table',
'  FOR i IN 1..APEX_APPLICATION.G_F05.COUNT LOOP',
'    INSERT INTO daily_sleep_quality_tracking (entry_id, sleep_quality_id)',
'    VALUES (l_entry_id, APEX_APPLICATION.G_F05(i));',
'  END LOOP;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38742016231065055227
);
wwv_flow_imp.component_end;
end;
/
